#include "rdfw.hpp"
#include <cassert>
#include <iostream>
using namespace _home;
namespace _home {struct ScoreSemanticsTestAccess {static bool ask(RDFW& w){return w.GetSmallObjectStatus(3);}};}
int main(int argc,char**argv){
 auto w=std::make_shared<RDFW>();char n[]="edge-claim",p[]="-path";char*args[]={n,p,argv[1]};w->Init(3,args);w->stage=2;
 assert(w->ParseEnv("(hold 0) (plate 0) (at 0 1) (sort 1 human) (size 1 big) (at 1 1) (sort 2 cupboard) (size 2 big) (type 2 container) (at 2 1) (opened 2) (sort 3 cup) (size 3 small) (inside 3 2) (sort 4 closet) (size 4 big) (type 4 container) (at 4 1) (opened 4)"));
 w->SetInsideRelation(3,2,1,true,EvidenceSource::ACTION_SUCCESS);
 w->SetInsideRelation(3,4,1,false,EvidenceSource::ASK_ANSWER);
 assert(w->InsideRelation(3,2)==1);
 w->SetAskResult("at(3,5)");const bool accepted=ScoreSemanticsTestAccess::ask(*w);
 std::cout<<"accepted="<<accepted<<" confirmed edge="<<w->InsideRelation(3,2)<<std::endl;
 assert(w->InsideRelation(3,2)==1);
}
