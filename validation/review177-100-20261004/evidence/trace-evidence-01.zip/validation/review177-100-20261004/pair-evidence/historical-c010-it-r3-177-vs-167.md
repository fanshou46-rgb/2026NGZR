# historical-c010-it-r3-177 vs 167

共同动作前缀 6；下一动作：PickUp 4 → Sense 。

## 官方指标

{
  "delta_base": 16,
  "delta_official_score": 26,
  "delta_raw_score": 26,
  "delta_final_goals": 0,
  "delta_credited_constraints": 0,
  "delta_action_cost": -16,
  "delta_platform_seconds": -0.4999999999999999,
  "delta_failed_actions": -2
}

## 基线动作

["PutDown 3", "PickUp 5", "AskLoc 5", "PickUp 5", "Move 1", "AskLoc 4", "PickUp 4", "Move 1", "AskLoc 1", "Move 1", "AskLoc 1", "Sense ", "PutDown 4"]

## 最新版动作

["PutDown 3", "PickUp 5", "AskLoc 5", "PickUp 5", "Move 1", "AskLoc 4", "Sense "]

## 最新版候选/执行/停止日志（原始顺序）

{"schema": "probe.v2", "event": "candidate", "world_revision": 4, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "nonpositive_answer_branch_value", "closed_reason": "", "signature": "ask:5", "kind": "AskLoc", "target_location": -1, "eligible": false, "information_estimate": 0, "expected_gain": -2, "probability_upper": 1, "residual_mass": 1, "terminal_goal_loss": 0, "answer_branches_evaluated": true, "answer_cache_hit": false, "answer_direct_value": 0, "answer_after_value": 0, "answer_net_value": -2, "answer_branch_count": 4, "continuation_cost": 0, "constraint_risk_count": 0, "cost": 2, "duration_ms": 100, "fact_count": 2, "potential_goal_value": 40, "stable_id": 1, "constraint_result": "constraint_safe", "facts": [{"field": "LOCATION", "id": 5, "task": 0, "stable_task_id": 1, "reason": "conflict", "location_hints": [{"location": 2, "source": "object_location:claim_source=9"}]}, {"field": "INSIDE", "id": 5, "task": 0, "stable_task_id": 1, "reason": "unverified", "location_hints": [{"location": 2, "source": "object_location:claim_source=9"}]}], "answer_branches": [{"reply": ["*", -2], "probability": 0.33, "route": ["?", -1], "posterior_match": 0, "value": 0}, {"reply": ["?", -1], "probability": 0.1, "route": ["?", -1], "posterior_match": 0, "value": 0}, {"reply": ["a", 1], "probability": 0.3216, "route": ["?", -1], "posterior_match": 0, "value": 0}, {"reply": ["a", 2], "probability": 0.2484, "route": ["?", -1], "posterior_match": 0, "value": 0}], "verification_routes": [{"hypothesis": ["a", 1], "success_value": 0, "failure_value": -465, "success_cost": 0, "duration_ms": 0, "feasible": false, "requires_new_answer": false, "reason": "constraint_safety_unknown"}]}

{"schema": "probe.v2", "event": "stop", "world_revision": 4, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "no_task_and_no_legal_probe", "closed_reason": ""}

## 原始路径

validation/review177-100-20261004/runs/historical-c010-it-r3-167

validation/review177-100-20261004/runs/historical-c010-it-r3-177

日志中的首次动作分叉不是自动的因果结论；模块归因见总报告。

## 官方目标与公共反馈补充

{
  "suite": "historical",
  "id": "c010",
  "mode": "it",
  "round": 3,
  "control": "167",
  "first_public_feedback_divergence": 6,
  "baseline_next_feedback": "PickUp 4|true",
  "latest_next_feedback": "Sense | 2 3 4 1",
  "lost_official_goal_ids": "[]",
  "gained_official_goal_ids": "[]",
  "goal_or_base_changed": true,
  "evidence": "historical-c010-it-r3-177-vs-167.md"
}

首个动作/反馈分叉是定位入口；关键决策须结合下列候选和停止原因。相同种子不保证动作分叉后还消费同一随机序列。

### 基线完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=0 behave=pickup legacy_choice=true eligible=true complete=true actions=2 duration_ms=200 action_cost=4 score_before=0 score_after=36 marginal_score=36 utility=36 gained_goals=[0] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Deadline] phase=main-loop task_index=0 behave=pickup can_finish=true remaining_plan_ms=200 safety_ms=300 budget_remaining_ms=4998
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=1 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=-8 score_after=27 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Candidate] phase=must-choose-one rank=1 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=-8 score_after=27 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Candidate] phase=must-choose-one rank=1 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=-8 score_after=27 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[3B][Deadline] phase=must-choose-one task_index=0 can_finish=false reason=incomplete_projection actions=2
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=1 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=-8 score_after=27 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=1 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=-8 score_after=27 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=2 behave=multi-goto-puton actions=4 duration_ms=420 action_cost=9 marginal_score=31 utility=31 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=2 can_finish=true remaining_plan_ms=420 tail_reserve_ms=100 platform_remaining_ms=4590 complete=true
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=1 task_index=0 behave=pickup legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=9 score_after=5 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3A][final] goals=1/2 (unknown=1), constraints=0/23 (unknown=22), base_score=9, action_cost=31, elapsed=1271ms, remaining=3729ms
[LOG]:[36m[3A][final] completed_goals=[1:goto], satisfied_constraints=[]

### 最新版完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=0 behave=pickup legacy_choice=false eligible=true complete=true actions=2 duration_ms=200 action_cost=4 score_before=0 score_after=36 marginal_score=36 utility=36 gained_goals=[0] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=pickup can_finish=true remaining_plan_ms=200 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=pickup can_finish=true remaining_plan_ms=200 safety_ms=200 budget_remaining_ms=4998
[LOG]:[Scheduler] greedy task=0 marginal=36 remaining_ms=4998 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_storage cumulative_ms=0
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=0 behave=pickup can_finish=true remaining_plan_ms=200 safety_ms=200 budget_remaining_ms=4998
[LOG]:[Scheduler] result task=0 stable_id=1 success=false revision=2 attempts=1
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=-8 score_after=27 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4575
[LOG]:[Scheduler] greedy task=1 marginal=35 remaining_ms=4575 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_storage cumulative_ms=0
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4575
[LOG]:[Scheduler] result task=1 stable_id=0 success=true revision=4 attempts=0
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=0 behave=pickup legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=25 score_after=21 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]
[LOG]:[Scheduler] filtered task=0 stable_id=1 marginal=-4 reason=incomplete_projection
[LOG]:[Scheduler] greedy task=18446744073709551615 marginal=0 remaining_ms=4231 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_storage cumulative_ms=0
[LOG]:[Probe] {"schema":"probe.v2","event":"legacy_proposal","world_revision":4,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"0","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":4,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=0,stable_id=1,filter=incomplete_projection","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":4,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=0,stable_id=1,filter=incomplete_projection,fact=LOCATION:5,reason=conflict","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":4,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=0,stable_id=1,filter=incomplete_projection,fact=INSIDE:5,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"candidate","world_revision":4,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"nonpositive_answer_branch_value","closed_reason":"","signature":"ask:5","kind":"AskLoc","target_location":-1,"eligible":false,"information_estimate":0,"expected_gain":-2,"probability_upper":1,"residual_mass":1,"terminal_goal_loss":0,"answer_branches_evaluated":true,"answer_cache_hit":false,"answer_direct_value":0,"answer_after_value":0,"answer_net_value":-2,"answer_branch_count":4,"continuation_cost":0,"constraint_risk_count":0,"cost":2,"duration_ms":100,"fact_count":2,"potential_goal_value":40,"stable_id":1,"constraint_result":"constraint_safe","facts":[{"field":"LOCATION","id":5,"task":0,"stable_task_id":1,"reason":"conflict","location_hints":[{"location":2,"source":"object_location:claim_source=9"}]},{"field":"INSIDE","id":5,"task":0,"stable_task_id":1,"reason":"unverified","location_hints":[{"location":2,"source":"object_location:claim_source=9"}]}],"answer_branches":[{"reply":["*",-2],"probability":0.33,"route":["?",-1],"posterior_match":0,"value":0},{"reply":["?",-1],"probability":0.1,"route":["?",-1],"posterior_match":0,"value":0},{"reply":["a",1],"probability":0.3216,"route":["?",-1],"posterior_match":0,"value":0},{"reply":["a",2],"probability":0.2484,"route":["?",-1],"posterior_match":0,"value":0}],"verification_routes":[{"hypothesis":["a",1],"success_value":0,"failure_value":-465,"success_cost":0,"duration_ms":0,"feasible":false,"requires_new_answer":false,"reason":"constraint_safety_unknown"}]}
[LOG]:[Probe] {"schema":"probe.v2","event":"stop","world_revision":4,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"no_task_and_no_legal_probe","closed_reason":""}
[LOG]:[Scheduler] stop reason=no_qualified_positive_single
[LOG]:[36m[3A][final] goals=1/2 (unknown=1), constraints=0/23 (unknown=0), base_score=25, action_cost=15, elapsed=771ms, remaining=4229ms
[LOG]:[36m[3A][final] completed_goals=[1:goto], satisfied_constraints=[]
