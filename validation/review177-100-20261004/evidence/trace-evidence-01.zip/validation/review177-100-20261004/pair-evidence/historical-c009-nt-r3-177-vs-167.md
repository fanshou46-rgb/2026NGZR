# historical-c009-nt-r3-177 vs 167

共同动作前缀 3；下一动作：PickUp 16 → Move 6。

## 官方指标

{
  "delta_base": -6,
  "delta_official_score": -10,
  "delta_raw_score": -10,
  "delta_final_goals": 0,
  "delta_credited_constraints": 0,
  "delta_action_cost": 6,
  "delta_platform_seconds": 0.22199999999999998,
  "delta_failed_actions": 0
}

## 基线动作

["FromPlate 10", "Sense ", "PutDown 10", "PickUp 16", "Move 7", "PutDown 16", "Open 7", "PickUp 16", "PutIn 16 7", "Move 5", "PickUp 11", "Move 4", "Sense ", "PutDown 11", "Move 2", "PickUp 13", "Move 5", "Sense ", "PutDown 13", "Move 6", "Open 6", "TakeOut 14 6"]

## 最新版动作

["FromPlate 10", "Sense ", "PutDown 10", "Move 6", "Open 6", "TakeOut 14 6", "PutDown 14", "Move 5", "PickUp 11", "Move 4", "Sense ", "PutDown 11", "Move 2", "PickUp 13", "Move 5", "Sense ", "PutDown 13", "Move 1", "PickUp 16", "Move 7", "PutDown 16", "Open 7", "PickUp 16", "PutIn 16 7"]

## 最新版候选/执行/停止日志（原始顺序）

## 原始路径

validation/review177-100-20261004/runs/historical-c009-nt-r3-167

validation/review177-100-20261004/runs/historical-c009-nt-r3-177

日志中的首次动作分叉不是自动的因果结论；模块归因见总报告。

## 官方目标与公共反馈补充

{
  "suite": "historical",
  "id": "c009",
  "mode": "nt",
  "round": 3,
  "control": "167",
  "first_public_feedback_divergence": 3,
  "baseline_next_feedback": "PickUp 16|true",
  "latest_next_feedback": "Move 6|true",
  "lost_official_goal_ids": "[]",
  "gained_official_goal_ids": "[]",
  "goal_or_base_changed": true,
  "evidence": "historical-c009-nt-r3-177-vs-167.md"
}

首个动作/反馈分叉是定位入口；关键决策须结合下列候选和停止原因。相同种子不保证动作分叉后还消费同一随机序列。

### 基线完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=0 behave=give legacy_choice=true eligible=true complete=true actions=3 duration_ms=300 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[0] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=2 task_index=4 behave=takeout legacy_choice=false eligible=true complete=true actions=3 duration_ms=320 action_cost=8 score_before=0 score_after=32 marginal_score=32 utility=32 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=3 task_index=2 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=0 score_after=27 marginal_score=27 utility=27 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=4 task_index=3 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=0 score_after=27 marginal_score=27 utility=27 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=5 task_index=1 behave=putin legacy_choice=false eligible=true complete=true actions=6 duration_ms=620 action_cost=14 score_before=0 score_after=26 marginal_score=26 utility=26 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=main-loop task_index=0 behave=give can_finish=true remaining_plan_ms=300 safety_ms=300 budget_remaining_ms=4999
[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=4 behave=takeout legacy_choice=false eligible=true complete=true actions=3 duration_ms=320 action_cost=8 score_before=35 score_after=67 marginal_score=32 utility=32 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=2 task_index=2 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=35 score_after=62 marginal_score=27 utility=27 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=3 task_index=3 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=35 score_after=62 marginal_score=27 utility=27 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=4 task_index=1 behave=putin legacy_choice=true eligible=true complete=true actions=6 duration_ms=620 action_cost=14 score_before=35 score_after=61 marginal_score=26 utility=26 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=main-loop task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=300 budget_remaining_ms=4643
[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=4 behave=takeout legacy_choice=false eligible=true complete=true actions=3 duration_ms=320 action_cost=8 score_before=61 score_after=93 marginal_score=32 utility=32 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=2 task_index=2 behave=puton legacy_choice=true eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=61 score_after=88 marginal_score=27 utility=27 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=3 task_index=3 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=61 score_after=88 marginal_score=27 utility=27 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=main-loop task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=300 budget_remaining_ms=3977
[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=4 behave=takeout legacy_choice=false eligible=true complete=true actions=3 duration_ms=320 action_cost=8 score_before=88 score_after=120 marginal_score=32 utility=32 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=2 task_index=3 behave=puton legacy_choice=true eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=88 score_after=115 marginal_score=27 utility=27 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=main-loop task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=300 budget_remaining_ms=3413
[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=4 behave=takeout legacy_choice=true eligible=true complete=true actions=3 duration_ms=320 action_cost=8 score_before=115 score_after=147 marginal_score=32 utility=32 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=main-loop task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=300 budget_remaining_ms=2881
[LOG]:[36m[3A][final] goals=5/5 (unknown=0), constraints=0/0 (unknown=0), base_score=147, action_cost=53, elapsed=2475ms, remaining=2525ms
[LOG]:[36m[3A][final] completed_goals=[0:give,1:putin,2:puton,3:puton,4:takeout], satisfied_constraints=[]

### 最新版完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=0 behave=give legacy_choice=false eligible=true complete=true actions=3 duration_ms=300 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[0] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=4 behave=takeout legacy_choice=false eligible=true complete=true actions=3 duration_ms=320 action_cost=8 score_before=0 score_after=32 marginal_score=32 utility=32 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=3 task_index=2 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=0 score_after=27 marginal_score=27 utility=27 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=4 task_index=3 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=0 score_after=27 marginal_score=27 utility=27 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=5 task_index=1 behave=putin legacy_choice=false eligible=true complete=true actions=6 duration_ms=620 action_cost=14 score_before=0 score_after=26 marginal_score=26 utility=26 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=give can_finish=true remaining_plan_ms=300 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=give can_finish=true remaining_plan_ms=300 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=give can_finish=true remaining_plan_ms=300 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=5000
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=give can_finish=true remaining_plan_ms=300 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=give can_finish=true remaining_plan_ms=300 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4999
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4999
[LOG]:[Scheduler] greedy task=0 marginal=35 remaining_ms=4999 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_storage cumulative_ms=0
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=0 behave=give can_finish=true remaining_plan_ms=300 safety_ms=200 budget_remaining_ms=4999
[LOG]:[Scheduler] result task=0 stable_id=0 success=true revision=3 attempts=0
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=4 behave=takeout legacy_choice=false eligible=true complete=true actions=3 duration_ms=320 action_cost=8 score_before=35 score_after=67 marginal_score=32 utility=32 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=2 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=35 score_after=62 marginal_score=27 utility=27 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=3 task_index=3 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=35 score_after=62 marginal_score=27 utility=27 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=4 task_index=1 behave=putin legacy_choice=false eligible=true complete=true actions=6 duration_ms=620 action_cost=14 score_before=35 score_after=61 marginal_score=26 utility=26 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=620 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=4666
[LOG]:[Scheduler] greedy task=4 marginal=32 remaining_ms=4666 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_group_location cumulative_ms=0
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=4 behave=takeout can_finish=true remaining_plan_ms=320 safety_ms=200 budget_remaining_ms=4666
[LOG]:[Scheduler] result task=4 stable_id=4 success=true revision=6 attempts=0
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=2 behave=puton legacy_choice=false eligible=true complete=true actions=6 duration_ms=640 action_cost=15 score_before=67 score_after=92 marginal_score=25 utility=25 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=3 behave=puton legacy_choice=false eligible=true complete=true actions=6 duration_ms=640 action_cost=15 score_before=67 score_after=92 marginal_score=25 utility=25 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=3 task_index=1 behave=putin legacy_choice=false eligible=true complete=true actions=8 duration_ms=840 action_cost=20 score_before=67 score_after=87 marginal_score=20 utility=20 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=640 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=640 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=840 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=640 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=640 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=840 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=840 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=puton can_finish=true remaining_plan_ms=640 safety_ms=200 budget_remaining_ms=4334
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=640 safety_ms=200 budget_remaining_ms=4334
[LOG]:[Scheduler] greedy task=2 marginal=25 remaining_ms=4334 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_group_relation cumulative_ms=0
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=2 behave=puton can_finish=true remaining_plan_ms=640 safety_ms=200 budget_remaining_ms=4334
[LOG]:[Scheduler] result task=2 stable_id=2 success=true revision=12 attempts=0
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=3 behave=puton legacy_choice=false eligible=true complete=true actions=5 duration_ms=540 action_cost=13 score_before=92 score_after=119 marginal_score=27 utility=27 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=1 behave=putin legacy_choice=false eligible=true complete=true actions=7 duration_ms=740 action_cost=18 score_before=92 score_after=114 marginal_score=22 utility=22 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=3658
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=740 safety_ms=200 budget_remaining_ms=3658
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=740 safety_ms=200 budget_remaining_ms=3658
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=3658
[LOG]:[Scheduler] greedy task=3 marginal=27 remaining_ms=3658 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_group_location cumulative_ms=0
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=3 behave=puton can_finish=true remaining_plan_ms=540 safety_ms=200 budget_remaining_ms=3658
[LOG]:[Scheduler] result task=3 stable_id=3 success=true revision=17 attempts=0
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=1 behave=putin legacy_choice=false eligible=true complete=true actions=7 duration_ms=740 action_cost=18 score_before=119 score_after=141 marginal_score=22 utility=22 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=putin can_finish=true remaining_plan_ms=740 safety_ms=200 budget_remaining_ms=3090
[LOG]:[Scheduler] greedy task=1 marginal=22 remaining_ms=3090 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_group_relation cumulative_ms=0
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=1 behave=putin can_finish=true remaining_plan_ms=740 safety_ms=200 budget_remaining_ms=3090
[LOG]:[Scheduler] result task=1 stable_id=1 success=true revision=24 attempts=0
[LOG]:[Scheduler] stop reason=goals_complete_or_deadline
[LOG]:[36m[3A][final] goals=5/5 (unknown=0), constraints=0/0 (unknown=0), base_score=141, action_cost=59, elapsed=2697ms, remaining=2303ms
[LOG]:[36m[3A][final] completed_goals=[0:give,1:putin,2:puton,3:puton,4:takeout], satisfied_constraints=[]
