# historical-c001-it-r3-177 vs 167

共同动作前缀 4；下一动作：Move 2 → PickUp 6。

## 官方指标

{
  "delta_base": 24,
  "delta_official_score": 20,
  "delta_raw_score": 20,
  "delta_final_goals": 1,
  "delta_credited_constraints": 0,
  "delta_action_cost": 16,
  "delta_platform_seconds": 0.17300000000000004,
  "delta_failed_actions": 0
}

## 基线动作

["PutDown 24", "PickUp 24", "Sense ", "PutDown 24", "Move 2", "PickUp 7", "Move 1", "PutDown 7", "Move 3", "PickUp 8", "Move 1", "PutDown 8", "Move 4", "PickUp 9", "Move 1", "PutDown 9", "Move 5", "PickUp 10", "Move 1", "PutDown 10", "Move 6", "PickUp 11", "Move 1", "PutDown 11", "Move 7", "PickUp 12", "Move 1", "PutDown 12", "Move 8", "PickUp 13", "Move 1", "PutDown 13", "Move 9", "PickUp 15", "Move 1", "PutDown 15", "Move 10", "PickUp 16", "Move 1", "PutDown 16"]

## 最新版动作

["PutDown 24", "PickUp 24", "Sense ", "PutDown 24", "PickUp 6", "PutDown 6", "Move 2", "PickUp 7", "Move 1", "PutDown 7", "Move 3", "PickUp 8", "Move 1", "PutDown 8", "Move 4", "PickUp 9", "Move 1", "PutDown 9", "Move 5", "PickUp 10", "Move 1", "PutDown 10", "Move 6", "PickUp 11", "Move 1", "PutDown 11", "Move 7", "PickUp 12", "Move 1", "PutDown 12", "Move 8", "PickUp 13", "Move 1", "PutDown 13", "Move 9", "PickUp 15", "Move 1", "PutDown 15", "Move 10", "PickUp 16", "Move 1", "PutDown 16", "Move 12", "PickUp 18", "Move 1", "PutDown 18"]

## 最新版候选/执行/停止日志（原始顺序）

{"schema": "probe.v2", "event": "stop", "world_revision": 4, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "qualified_goto_tail", "closed_reason": ""}

{"schema": "probe.v2", "event": "stop", "world_revision": 46, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "deadline", "closed_reason": ""}

## 原始路径

validation/review177-100-20261004/runs/historical-c001-it-r3-167

validation/review177-100-20261004/runs/historical-c001-it-r3-177

日志中的首次动作分叉不是自动的因果结论；模块归因见总报告。

## 官方目标与公共反馈补充

{
  "suite": "historical",
  "id": "c001",
  "mode": "it",
  "round": 3,
  "control": "167",
  "first_public_feedback_divergence": 4,
  "baseline_next_feedback": "Move 2|true",
  "latest_next_feedback": "PickUp 6|true",
  "lost_official_goal_ids": "[]",
  "gained_official_goal_ids": "[13]",
  "goal_or_base_changed": true,
  "evidence": "historical-c001-it-r3-177-vs-167.md"
}

首个动作/反馈分叉是定位入口；关键决策须结合下列候选和停止原因。相同种子不保证动作分叉后还消费同一随机序列。

### 基线完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=1 behave=give legacy_choice=false eligible=true complete=true actions=4 duration_ms=400 action_cost=7 score_before=0 score_after=73 marginal_score=73 utility=73 gained_goals=[1,18] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=2 task_index=0 behave=puton legacy_choice=true eligible=true complete=false actions=3 duration_ms=300 action_cost=6 score_before=0 score_after=-6 marginal_score=-6 utility=-6 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=main-loop task_index=0 can_finish=false reason=incomplete_projection actions=3
[LOG]:[36m[3B][Candidate] phase=main-loop rank=1 task_index=1 behave=give legacy_choice=true eligible=true complete=true actions=4 duration_ms=400 action_cost=7 score_before=0 score_after=73 marginal_score=73 utility=73 gained_goals=[1,18] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=main-loop rank=2 task_index=0 behave=puton legacy_choice=false eligible=true complete=false actions=3 duration_ms=300 action_cost=6 score_before=0 score_after=-6 marginal_score=-6 utility=-6 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=main-loop task_index=1 behave=give can_finish=true remaining_plan_ms=400 safety_ms=300 budget_remaining_ms=4996
[LOG]:[36m[3B][Candidate] phase=check-phase rank=1 task_index=0 behave=puton legacy_choice=true eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=73 score_after=69 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=1 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,11] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=2 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,11] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=3 task_index=0 behave=puton legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=73 score_after=69 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=4 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[2] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=5 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[3] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=6 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[4] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=7 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[5] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=8 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[6] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=9 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[7] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=10 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[8] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=11 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[10] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[12] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=13 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[13] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=14 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[14] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=15 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[15] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=16 task_index=16 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[16] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=stop-rescan rank=17 task_index=17 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[17] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=1 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,11] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=2 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,11] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=3 task_index=0 behave=puton legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=73 score_after=69 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=4 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[2] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=5 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[3] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=6 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[4] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=7 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[5] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=8 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[6] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=9 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[7] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=10 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[8] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=11 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[10] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[12] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=13 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[13] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=14 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[14] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=15 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[15] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=16 task_index=16 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[16] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=17 task_index=17 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[17] lost_goals=[18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=0 duration_ms=0 action_cost=0 marginal_score=0 utility=0 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=0 tail_reserve_ms=100 platform_remaining_ms=4603 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[17] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=4603 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[16] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=4164 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[15] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3708 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[14] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3232 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[13] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2764 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[12] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2276 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=68 utility=68 gained_goals=[9,11] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1824 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=0 duration_ms=0 action_cost=0 marginal_score=0 utility=0 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=0 tail_reserve_ms=100 platform_remaining_ms=1352 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1351 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[10] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=855 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=false remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=436 complete=true
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=1 task_index=0 behave=puton legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=365 score_after=361 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=2 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=365 score_after=-40 marginal_score=-405 utility=-405 gained_goals=[3] lost_goals=[2,9,10,11,12,13,14,15,16,17,18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=3 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=365 score_after=-40 marginal_score=-405 utility=-405 gained_goals=[4] lost_goals=[2,9,10,11,12,13,14,15,16,17,18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=4 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=365 score_after=-40 marginal_score=-405 utility=-405 gained_goals=[5] lost_goals=[2,9,10,11,12,13,14,15,16,17,18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=5 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=365 score_after=-40 marginal_score=-405 utility=-405 gained_goals=[6] lost_goals=[2,9,10,11,12,13,14,15,16,17,18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=6 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=365 score_after=-40 marginal_score=-405 utility=-405 gained_goals=[7] lost_goals=[2,9,10,11,12,13,14,15,16,17,18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=7 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=365 score_after=-40 marginal_score=-405 utility=-405 gained_goals=[8] lost_goals=[2,9,10,11,12,13,14,15,16,17,18] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3A][final] goals=12/19 (unknown=7), constraints=0/0 (unknown=0), base_score=365, action_cost=115, elapsed=4566ms, remaining=434ms
[LOG]:[36m[3A][final] completed_goals=[1:give,2:goto,9:goto,10:goto,11:goto,12:goto,13:goto,14:goto,15:goto,16:goto,17:goto,18:goto], satisfied_constraints=[]

### 最新版完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=0 behave=give legacy_choice=false eligible=true complete=true actions=4 duration_ms=400 action_cost=7 score_before=0 score_after=73 marginal_score=73 utility=73 gained_goals=[0,2] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=1 behave=puton legacy_choice=false eligible=true complete=false actions=3 duration_ms=300 action_cost=6 score_before=0 score_after=-6 marginal_score=-6 utility=-6 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=give can_finish=true remaining_plan_ms=400 safety_ms=200 budget_remaining_ms=4998
[LOG]:[Scheduler] filtered task=1 stable_id=18 marginal=-6 reason=incomplete_projection
[LOG]:[Scheduler] greedy task=0 marginal=73 remaining_ms=4998 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unsupported_or_time stage=2 deferred_goto=true
[LOG]:[36m[3B][Deadline] phase=greedy-execution task_index=0 behave=give can_finish=true remaining_plan_ms=400 safety_ms=200 budget_remaining_ms=4998
[LOG]:[Scheduler] result task=0 stable_id=0 success=true revision=4 attempts=0
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=1 behave=puton legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=73 score_after=69 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[Scheduler] filtered task=1 stable_id=18 marginal=-4 reason=incomplete_projection
[LOG]:[Scheduler] greedy task=18446744073709551615 marginal=0 remaining_ms=4550 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unsupported_or_time stage=2 deferred_goto=true
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=1 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,12] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=2 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,12] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=3 task_index=1 behave=puton legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=73 score_after=69 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=4 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[3] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=5 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[4] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=6 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[5] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=7 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[6] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[7] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=9 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[8] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[10] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[11] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=12 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[13] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=13 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[14] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=14 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[15] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=15 task_index=16 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[16] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=16 task_index=17 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[17] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=17 task_index=18 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[18] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=16 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=17 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=18 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=16 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=17 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=18 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4547
[LOG]:[Scheduler] filtered task=1 stable_id=18 marginal=-4 reason=incomplete_projection
[LOG]:[Scheduler] filtered task=3 stable_id=2 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=4 stable_id=3 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=5 stable_id=4 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=6 stable_id=5 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=7 stable_id=6 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=8 stable_id=7 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=10 stable_id=9 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=11 stable_id=10 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=13 stable_id=12 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=14 stable_id=13 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=15 stable_id=14 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=16 stable_id=15 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=17 stable_id=16 marginal=-5 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=18 stable_id=17 marginal=-5 reason=nonpositive_single
[LOG]:[Probe] {"schema":"probe.v2","event":"stop","world_revision":4,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"qualified_goto_tail","closed_reason":""}
[LOG]:[Scheduler] defer_to_goto_tail reason=no_qualified_positive_single
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=1 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,12] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=2 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=108 marginal_score=35 utility=35 gained_goals=[9,12] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=3 task_index=1 behave=puton legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=73 score_after=69 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=4 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[3] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=5 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[4] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=6 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[5] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=7 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[6] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[7] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=9 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[8] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[10] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[11] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=12 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[13] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=13 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[14] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=14 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[15] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=15 task_index=16 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[16] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=16 task_index=17 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[17] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=17 task_index=18 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=73 score_after=68 marginal_score=-5 utility=-5 gained_goals=[18] lost_goals=[2] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=2 duration_ms=200 action_cost=4 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=200 tail_reserve_ms=100 platform_remaining_ms=4543 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[3] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=4338 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[4] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3974 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[5] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3550 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3170 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[7] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2726 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2338 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=68 utility=68 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1870 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=0 duration_ms=0 action_cost=0 marginal_score=0 utility=0 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=0 tail_reserve_ms=100 platform_remaining_ms=1475 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[10] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1474 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[11] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1098 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[13] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=686 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=19 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[14] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=19 can_finish=false remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=262 complete=true
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=1 behave=puton legacy_choice=false eligible=true complete=false actions=2 duration_ms=200 action_cost=4 score_before=389 score_after=385 marginal_score=-4 utility=-4 gained_goals=[] lost_goals=[] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=389 score_after=-56 marginal_score=-445 utility=-445 gained_goals=[14] lost_goals=[2,3,4,5,6,7,8,9,10,11,12,13] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=3 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=389 score_after=-56 marginal_score=-445 utility=-445 gained_goals=[15] lost_goals=[2,3,4,5,6,7,8,9,10,11,12,13] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=4 task_index=16 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=389 score_after=-56 marginal_score=-445 utility=-445 gained_goals=[16] lost_goals=[2,3,4,5,6,7,8,9,10,11,12,13] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=5 task_index=17 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=389 score_after=-56 marginal_score=-445 utility=-445 gained_goals=[17] lost_goals=[2,3,4,5,6,7,8,9,10,11,12,13] broken_constraints=[] preserved_constraints=[]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=6 task_index=18 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=389 score_after=-56 marginal_score=-445 utility=-445 gained_goals=[18] lost_goals=[2,3,4,5,6,7,8,9,10,11,12,13] broken_constraints=[] preserved_constraints=[]
[LOG]:[Scheduler] filtered task=1 stable_id=18 marginal=-4 reason=incomplete_projection
[LOG]:[Scheduler] filtered task=14 stable_id=13 marginal=-445 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=15 stable_id=14 marginal=-445 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=16 stable_id=15 marginal=-445 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=17 stable_id=16 marginal=-445 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=18 stable_id=17 marginal=-445 reason=nonpositive_single
[LOG]:[Scheduler] greedy task=18446744073709551615 marginal=0 remaining_ms=260 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_storage cumulative_ms=0
[LOG]:[Probe] {"schema":"probe.v2","event":"stop","world_revision":46,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"deadline","closed_reason":""}
[LOG]:[Scheduler] stop reason=no_qualified_positive_single
[LOG]:[36m[3A][final] goals=13/19 (unknown=6), constraints=0/0 (unknown=0), base_score=389, action_cost=131, elapsed=4740ms, remaining=260ms
[LOG]:[36m[3A][final] completed_goals=[0:give,2:goto,3:goto,4:goto,5:goto,6:goto,7:goto,8:goto,9:goto,10:goto,11:goto,12:goto,13:goto], satisfied_constraints=[]
