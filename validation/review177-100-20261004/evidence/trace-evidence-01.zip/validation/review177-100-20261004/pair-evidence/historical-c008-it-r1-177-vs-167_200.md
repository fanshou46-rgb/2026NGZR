# historical-c008-it-r1-177 vs 167_200

共同动作前缀 3；下一动作：PickUp 7 → Move 7。

## 官方指标

{
  "delta_base": -26,
  "delta_official_score": -28,
  "delta_raw_score": -28,
  "delta_final_goals": 0,
  "delta_credited_constraints": -1,
  "delta_action_cost": 6,
  "delta_platform_seconds": 0.10299999999999976,
  "delta_failed_actions": 1
}

## 基线动作

["Move 10", "PickUp 6", "AskLoc 6", "PickUp 7", "Sense ", "AskLoc 20", "PutDown 7", "PickUp 14", "Move 2", "Sense ", "PutDown 14", "Move 15", "PickUp 2", "Move 2", "PutDown 2", "Move 5", "PickUp 3", "Move 2", "PutDown 3", "Move 13", "PickUp 4", "Move 2", "PutDown 4", "Move 8", "PickUp 9", "Move 2", "PutDown 9", "Move 7", "PickUp 10", "Move 2", "PutDown 10", "Move 7", "PickUp 11", "Move 2", "PutDown 11", "Move 8", "PickUp 12", "Move 2", "PutDown 12"]

## 最新版动作

["Move 10", "PickUp 6", "AskLoc 6", "Move 7", "PickUp 6", "Move 10", "PickUp 7", "Sense ", "AskLoc 20", "Move 2", "Sense ", "PutDown 7", "Move 10", "PickUp 14", "Move 2", "PutDown 14", "Move 15", "PickUp 2", "Move 2", "PutDown 2", "Move 5", "PickUp 3", "Move 2", "PutDown 3", "Move 13", "PickUp 4", "Move 2", "PutDown 4", "Move 8", "PickUp 9", "Move 2", "PutDown 9", "Move 7", "PickUp 10", "Move 2", "PutDown 10", "Move 7", "PickUp 11", "Move 2", "PutDown 11"]

## 最新版候选/执行/停止日志（原始顺序）

{"schema": "probe.v2", "event": "stop", "world_revision": 0, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "qualified_goto_tail", "closed_reason": ""}

{"schema": "probe.v2", "event": "stop", "world_revision": 38, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "deadline", "closed_reason": ""}

## 原始路径

validation/review177-100-20261004/runs/historical-c008-it-r1-167_200

validation/review177-100-20261004/runs/historical-c008-it-r1-177

日志中的首次动作分叉不是自动的因果结论；模块归因见总报告。

## 官方目标与公共反馈补充

{
  "suite": "historical",
  "id": "c008",
  "mode": "it",
  "round": 1,
  "control": "167_200",
  "first_public_feedback_divergence": 3,
  "baseline_next_feedback": "PickUp 7|true",
  "latest_next_feedback": "Move 7|true",
  "lost_official_goal_ids": "[19]",
  "gained_official_goal_ids": "[5]",
  "goal_or_base_changed": true,
  "evidence": "historical-c008-it-r1-177-vs-167_200.md"
}

首个动作/反馈分叉是定位入口；关键决策须结合下列候选和停止原因。相同种子不保证动作分叉后还消费同一随机序列。

### 基线完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=multi-goto rank=1 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=2 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=3 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=4 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=5 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=6 task_index=0 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=7 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=9 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=13 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=14 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=15 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=16 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=420 action_cost=9 marginal_score=191 utility=191 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[3,6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=420 tail_reserve_ms=100 platform_remaining_ms=4996 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=3 duration_ms=300 action_cost=5 marginal_score=155 utility=155 gained_goals=[4,5,13,14] lost_goals=[] broken_constraints=[3,6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=300 tail_reserve_ms=100 platform_remaining_ms=4673 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=5 duration_ms=520 action_cost=11 marginal_score=-51 utility=-51 gained_goals=[13] lost_goals=[4,14] broken_constraints=[6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=520 tail_reserve_ms=100 platform_remaining_ms=4330 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[0] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3721 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3237 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2765 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[9] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2294 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[10] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1822 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1341 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=866 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=false remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=381 complete=true
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=1 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=292 score_after=-33 marginal_score=-325 utility=-325 gained_goals=[4,14] lost_goals=[0,1,2,3,5,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=2 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=292 score_after=-33 marginal_score=-325 utility=-325 gained_goals=[4,14] lost_goals=[0,1,2,3,5,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=3 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=292 score_after=-73 marginal_score=-365 utility=-365 gained_goals=[6] lost_goals=[0,1,2,3,5,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=4 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=292 score_after=-73 marginal_score=-365 utility=-365 gained_goals=[7] lost_goals=[0,1,2,3,5,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=5 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=292 score_after=-73 marginal_score=-365 utility=-365 gained_goals=[8] lost_goals=[0,1,2,3,5,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=6 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=292 score_after=-73 marginal_score=-365 utility=-365 gained_goals=[15] lost_goals=[0,1,2,3,5,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[36m[3A][final] goals=10/16 (unknown=4), constraints=0/9 (unknown=5), base_score=292, action_cost=108, elapsed=4621ms, remaining=379ms
[LOG]:[36m[3A][final] completed_goals=[0:goto,1:goto,2:goto,3:goto,5:goto,9:goto,10:goto,11:goto,12:goto,13:goto], satisfied_constraints=[]

### 最新版完整调度/候选/执行/终态日志

[LOG]:[Scheduler] greedy task=18446744073709551615 marginal=0 remaining_ms=4999 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unsupported_or_time stage=2 deferred_goto=true
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=1 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=2 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=3 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=4 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=5 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=6 task_index=0 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=7 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=9 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=13 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=14 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=15 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=16 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[Probe] {"schema":"probe.v2","event":"stop","world_revision":0,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"qualified_goto_tail","closed_reason":""}
[LOG]:[Scheduler] defer_to_goto_tail reason=no_qualified_positive_single
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=1 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=2 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=3 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=4 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=5 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=6 task_index=0 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=7 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=9 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=13 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=14 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=15 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=16 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=420 action_cost=9 marginal_score=191 utility=191 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[3,6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=420 tail_reserve_ms=100 platform_remaining_ms=4990 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=420 action_cost=9 marginal_score=151 utility=151 gained_goals=[4,5,13,14] lost_goals=[] broken_constraints=[3,6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=420 tail_reserve_ms=100 platform_remaining_ms=4388 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[5] lost_goals=[] broken_constraints=[6] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3553 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[0] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3120 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2648 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2173 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[9] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1716 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[10] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1240 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[11] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=768 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[12] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=false remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=280 complete=true
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=286 score_after=-79 marginal_score=-365 utility=-365 gained_goals=[6] lost_goals=[0,1,2,3,4,5,9,10,11,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=286 score_after=-79 marginal_score=-365 utility=-365 gained_goals=[7] lost_goals=[0,1,2,3,4,5,9,10,11,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=3 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=286 score_after=-79 marginal_score=-365 utility=-365 gained_goals=[8] lost_goals=[0,1,2,3,4,5,9,10,11,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=4 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=286 score_after=-79 marginal_score=-365 utility=-365 gained_goals=[12] lost_goals=[0,1,2,3,4,5,9,10,11,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=5 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=286 score_after=-79 marginal_score=-365 utility=-365 gained_goals=[14] lost_goals=[0,1,2,3,4,5,9,10,11,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=6 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=286 score_after=-79 marginal_score=-365 utility=-365 gained_goals=[15] lost_goals=[0,1,2,3,4,5,9,10,11,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[Scheduler] filtered task=6 stable_id=6 marginal=-365 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=7 stable_id=7 marginal=-365 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=8 stable_id=8 marginal=-365 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=12 stable_id=12 marginal=-365 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=14 stable_id=14 marginal=-365 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=15 stable_id=15 marginal=-365 reason=nonpositive_single
[LOG]:[Scheduler] greedy task=18446744073709551615 marginal=0 remaining_ms=277 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_storage cumulative_ms=0
[LOG]:[Probe] {"schema":"probe.v2","event":"stop","world_revision":38,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"deadline","closed_reason":""}
[LOG]:[Scheduler] stop reason=no_qualified_positive_single
[LOG]:[36m[3A][final] goals=10/16 (unknown=5), constraints=0/9 (unknown=5), base_score=286, action_cost=114, elapsed=4723ms, remaining=277ms
[LOG]:[36m[3A][final] completed_goals=[0:goto,1:goto,2:goto,3:goto,4:goto,5:goto,9:goto,10:goto,11:goto,13:goto], satisfied_constraints=[]
