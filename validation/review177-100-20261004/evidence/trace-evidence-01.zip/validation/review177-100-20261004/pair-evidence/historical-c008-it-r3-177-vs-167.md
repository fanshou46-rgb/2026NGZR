# historical-c008-it-r3-177 vs 167

共同动作前缀 3；下一动作：PickUp 7 → Move 2。

## 官方指标

{
  "delta_base": -76,
  "delta_official_score": -70,
  "delta_raw_score": -70,
  "delta_final_goals": -1,
  "delta_credited_constraints": -2,
  "delta_action_cost": -4,
  "delta_platform_seconds": -0.3150000000000004,
  "delta_failed_actions": 0
}

## 基线动作

["Move 10", "PickUp 6", "AskLoc 6", "PickUp 7", "Sense ", "AskLoc 20", "PutDown 7", "PickUp 14", "Move 1", "Sense ", "AskLoc 20", "PutDown 14", "Move 15", "PickUp 2", "Move 2", "Sense ", "PutDown 2", "Move 5", "PickUp 3", "Move 2", "PutDown 3", "Move 13", "PickUp 4", "Move 2", "PutDown 4", "Move 8", "PickUp 9", "Move 2", "PutDown 9", "Move 7", "PickUp 10", "Move 2", "PutDown 10", "Move 7", "PickUp 11", "Move 2", "PutDown 11", "Move 8", "PickUp 12", "Move 2", "PutDown 12"]

## 最新版动作

["Move 10", "PickUp 6", "AskLoc 6", "Move 2", "PickUp 6", "Move 10", "Sense ", "AskLoc 20", "Move 1", "Sense ", "AskLoc 20", "Move 2", "Sense ", "PutDown 6", "Move 10", "PickUp 7", "Move 2", "PutDown 7", "Move 10", "PickUp 14", "Move 2", "PutDown 14", "Move 15", "PickUp 2", "Move 2", "PutDown 2", "Move 5", "PickUp 3", "Move 2", "PutDown 3", "Move 13", "PickUp 4", "Move 2", "PutDown 4", "Move 8", "PickUp 9", "Move 2", "PutDown 9"]

## 最新版候选/执行/停止日志（原始顺序）

{"schema": "probe.v2", "event": "stop", "world_revision": 0, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "qualified_goto_tail", "closed_reason": ""}

{"schema": "probe.v2", "event": "candidate", "world_revision": 37, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "constraint_safety_unknown", "closed_reason": "", "signature": "sense_at:7", "kind": "MoveSense", "target_location": 7, "eligible": false, "information_estimate": 0.332386, "expected_gain": -381.733, "probability_upper": 1, "residual_mass": 0.463068, "terminal_goal_loss": 320, "answer_branches_evaluated": false, "answer_cache_hit": false, "answer_direct_value": 0, "answer_after_value": 0, "answer_net_value": 0, "answer_branch_count": 0, "continuation_cost": 10, "constraint_risk_count": 4, "cost": 5, "duration_ms": 220, "fact_count": 4, "potential_goal_value": 80, "stable_id": 10, "constraint_result": "constraint_safety_unknown", "facts": [{"field": "LOCATION", "id": 10, "task": 10, "stable_task_id": 10, "reason": "unverified", "location_hints": [{"location": 7, "source": "object_location:claim_source=1"}]}, {"field": "INSIDE", "id": 10, "task": 10, "stable_task_id": 10, "reason": "unverified", "location_hints": [{"location": 7, "source": "object_location:claim_source=1"}]}, {"field": "LOCATION", "id": 11, "task": 11, "stable_task_id": 11, "reason": "unverified", "location_hints": [{"location": 7, "source": "object_location:claim_source=1"}]}, {"field": "INSIDE", "id": 11, "task": 11, "stable_task_id": 11, "reason": "unverified", "location_hints": [{"location": 7, "source": "object_location:claim_source=1"}]}], "answer_branches": [], "verification_routes": []}

{"schema": "probe.v2", "event": "candidate", "world_revision": 37, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "constraint_safety_unknown", "closed_reason": "", "signature": "sense_at:11", "kind": "MoveSense", "target_location": 11, "eligible": false, "information_estimate": 0.332386, "expected_gain": -393.366, "probability_upper": 0.795455, "residual_mass": 0.463068, "terminal_goal_loss": 320, "answer_branches_evaluated": false, "answer_cache_hit": false, "answer_direct_value": 0, "answer_after_value": 0, "answer_net_value": 0, "answer_branch_count": 0, "continuation_cost": 5, "constraint_risk_count": 4, "cost": 5, "duration_ms": 220, "fact_count": 2, "potential_goal_value": 40, "stable_id": 6, "constraint_result": "constraint_safety_unknown", "facts": [{"field": "LOCATION", "id": 15, "task": 6, "stable_task_id": 6, "reason": "unverified", "location_hints": [{"location": 11, "source": "object_location:claim_source=1"}]}, {"field": "INSIDE", "id": 15, "task": 6, "stable_task_id": 6, "reason": "unverified", "location_hints": [{"location": 11, "source": "object_location:claim_source=1"}]}], "answer_branches": [], "verification_routes": []}

{"schema": "probe.v2", "event": "candidate", "world_revision": 37, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "constraint_safety_unknown", "closed_reason": "", "signature": "sense_at:13", "kind": "MoveSense", "target_location": 13, "eligible": false, "information_estimate": 0.332386, "expected_gain": -393.366, "probability_upper": 0.795455, "residual_mass": 0.463068, "terminal_goal_loss": 320, "answer_branches_evaluated": false, "answer_cache_hit": false, "answer_direct_value": 0, "answer_after_value": 0, "answer_net_value": 0, "answer_branch_count": 0, "continuation_cost": 5, "constraint_risk_count": 4, "cost": 5, "duration_ms": 220, "fact_count": 2, "potential_goal_value": 40, "stable_id": 7, "constraint_result": "constraint_safety_unknown", "facts": [{"field": "LOCATION", "id": 17, "task": 7, "stable_task_id": 7, "reason": "unverified", "location_hints": [{"location": 13, "source": "object_location:claim_source=1"}]}, {"field": "INSIDE", "id": 17, "task": 7, "stable_task_id": 7, "reason": "unverified", "location_hints": [{"location": 13, "source": "object_location:claim_source=1"}]}], "answer_branches": [], "verification_routes": []}

{"schema": "probe.v2", "event": "candidate", "world_revision": 37, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "constraint_safety_unknown", "closed_reason": "", "signature": "sense_at:14", "kind": "MoveSense", "target_location": 14, "eligible": false, "information_estimate": 0.332386, "expected_gain": -393.366, "probability_upper": 0.795455, "residual_mass": 0.463068, "terminal_goal_loss": 320, "answer_branches_evaluated": false, "answer_cache_hit": false, "answer_direct_value": 0, "answer_after_value": 0, "answer_net_value": 0, "answer_branch_count": 0, "continuation_cost": 5, "constraint_risk_count": 4, "cost": 5, "duration_ms": 220, "fact_count": 2, "potential_goal_value": 40, "stable_id": 8, "constraint_result": "constraint_safety_unknown", "facts": [{"field": "LOCATION", "id": 18, "task": 8, "stable_task_id": 8, "reason": "unverified", "location_hints": [{"location": 14, "source": "object_location:claim_source=1"}]}, {"field": "INSIDE", "id": 18, "task": 8, "stable_task_id": 8, "reason": "unverified", "location_hints": [{"location": 14, "source": "object_location:claim_source=1"}]}], "answer_branches": [], "verification_routes": []}

{"schema": "probe.v2", "event": "candidate", "world_revision": 37, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "constraint_safety_unknown", "closed_reason": "", "signature": "sense_at:8", "kind": "MoveSense", "target_location": 8, "eligible": false, "information_estimate": 0.332386, "expected_gain": -393.366, "probability_upper": 0.795455, "residual_mass": 0.463068, "terminal_goal_loss": 320, "answer_branches_evaluated": false, "answer_cache_hit": false, "answer_direct_value": 0, "answer_after_value": 0, "answer_net_value": 0, "answer_branch_count": 0, "continuation_cost": 5, "constraint_risk_count": 4, "cost": 5, "duration_ms": 220, "fact_count": 2, "potential_goal_value": 40, "stable_id": 12, "constraint_result": "constraint_safety_unknown", "facts": [{"field": "LOCATION", "id": 12, "task": 12, "stable_task_id": 12, "reason": "unverified", "location_hints": [{"location": 8, "source": "object_location:claim_source=1"}]}, {"field": "INSIDE", "id": 12, "task": 12, "stable_task_id": 12, "reason": "unverified", "location_hints": [{"location": 8, "source": "object_location:claim_source=1"}]}], "answer_branches": [], "verification_routes": []}

{"schema": "probe.v2", "event": "candidate", "world_revision": 37, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "constraint_safety_unknown", "closed_reason": "", "signature": "sense_at:15", "kind": "MoveSense", "target_location": 15, "eligible": false, "information_estimate": 0.590909, "expected_gain": -384.318, "probability_upper": 0.636364, "residual_mass": 0.0454545, "terminal_goal_loss": 320, "answer_branches_evaluated": false, "answer_cache_hit": false, "answer_direct_value": 0, "answer_after_value": 0, "answer_net_value": 0, "answer_branch_count": 0, "continuation_cost": 5, "constraint_risk_count": 4, "cost": 5, "duration_ms": 220, "fact_count": 1, "potential_goal_value": 40, "stable_id": 15, "constraint_result": "constraint_safety_unknown", "facts": [{"field": "LOCATION", "id": 22, "task": 15, "stable_task_id": 15, "reason": "unverified", "location_hints": [{"location": 15, "source": "object_location:claim_source=1"}]}], "answer_branches": [], "verification_routes": []}

{"schema": "probe.v2", "event": "stop", "world_revision": 37, "total_probes": 0, "probe_cost_spent": 0, "max_same_ask": 3, "authorized_constraint_risk_count": 0, "consecutive_no_progress": 0, "policy": [8, 2, 32], "reason": "constraint_rejected", "closed_reason": ""}

## 原始路径

validation/review177-100-20261004/runs/historical-c008-it-r3-167

validation/review177-100-20261004/runs/historical-c008-it-r3-177

日志中的首次动作分叉不是自动的因果结论；模块归因见总报告。

## 官方目标与公共反馈补充

{
  "suite": "historical",
  "id": "c008",
  "mode": "it",
  "round": 3,
  "control": "167",
  "first_public_feedback_divergence": 3,
  "baseline_next_feedback": "PickUp 7|true",
  "latest_next_feedback": "Move 2|true",
  "lost_official_goal_ids": "[17, 18, 19]",
  "gained_official_goal_ids": "[5, 12]",
  "goal_or_base_changed": true,
  "evidence": "historical-c008-it-r3-177-vs-167.md"
}

首个动作/反馈分叉是定位入口；关键决策须结合下列候选和停止原因。相同种子不保证动作分叉后还消费同一随机序列。

### 基线完整调度/候选/执行/终态日志

[LOG]:[36m[3B][Candidate] phase=multi-goto rank=1 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=2 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=3 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=4 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=5 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=6 task_index=0 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=7 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=9 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=13 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=14 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=15 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=16 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=420 action_cost=9 marginal_score=191 utility=191 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[3,6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=420 tail_reserve_ms=100 platform_remaining_ms=4997 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=3 duration_ms=300 action_cost=5 marginal_score=155 utility=155 gained_goals=[4,5,13,14] lost_goals=[] broken_constraints=[3,6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=300 tail_reserve_ms=100 platform_remaining_ms=4656 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=5 duration_ms=520 action_cost=11 marginal_score=-51 utility=-51 gained_goals=[13] lost_goals=[4,14] broken_constraints=[6,8] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=520 tail_reserve_ms=100 platform_remaining_ms=4320 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=6 duration_ms=640 action_cost=15 marginal_score=65 utility=65 gained_goals=[0,3,13] lost_goals=[5] broken_constraints=[8] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=640 tail_reserve_ms=100 platform_remaining_ms=3725 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3029 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2557 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[9] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2089 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[10] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1624 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1157 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=677 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=false remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=209 complete=true
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=1 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=249 score_after=-36 marginal_score=-285 utility=-285 gained_goals=[4,14] lost_goals=[0,1,2,3,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=2 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=249 score_after=-36 marginal_score=-285 utility=-285 gained_goals=[4,14] lost_goals=[0,1,2,3,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=3 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=249 score_after=-76 marginal_score=-325 utility=-325 gained_goals=[5] lost_goals=[0,1,2,3,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=4 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=249 score_after=-76 marginal_score=-325 utility=-325 gained_goals=[6] lost_goals=[0,1,2,3,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=5 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=249 score_after=-76 marginal_score=-325 utility=-325 gained_goals=[7] lost_goals=[0,1,2,3,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=6 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=249 score_after=-76 marginal_score=-325 utility=-325 gained_goals=[8] lost_goals=[0,1,2,3,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[36m[3B][Candidate] phase=terminal-recovery rank=7 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=249 score_after=-76 marginal_score=-325 utility=-325 gained_goals=[15] lost_goals=[0,1,2,3,9,10,11,12,13] broken_constraints=[] preserved_constraints=[0,1,2,4,5,7]
[LOG]:[36m[3A][final] goals=9/16 (unknown=4), constraints=0/9 (unknown=4), base_score=249, action_cost=111, elapsed=4793ms, remaining=207ms
[LOG]:[36m[3A][final] completed_goals=[0:goto,1:goto,2:goto,3:goto,9:goto,10:goto,11:goto,12:goto,13:goto], satisfied_constraints=[]

### 最新版完整调度/候选/执行/终态日志

[LOG]:[Scheduler] greedy task=18446744073709551615 marginal=0 remaining_ms=4999 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unsupported_or_time stage=2 deferred_goto=true
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=1 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=2 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=3 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=4 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=5 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=6 task_index=0 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=7 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=9 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=13 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=14 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=15 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=probe-tail-check rank=16 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4995
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=8 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=3 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=4 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=5 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=13 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=14 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=0 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=2 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=7 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=9 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=10 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=11 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=12 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=15 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=1 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[36m[3B][Deadline] phase=greedy-filter task_index=6 behave=goto can_finish=true remaining_plan_ms=220 safety_ms=200 budget_remaining_ms=4994
[LOG]:[Probe] {"schema":"probe.v2","event":"stop","world_revision":0,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"qualified_goto_tail","closed_reason":""}
[LOG]:[Scheduler] defer_to_goto_tail reason=no_qualified_positive_single
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=1 task_index=3 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=2 task_index=4 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=3 task_index=5 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=4 task_index=13 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=5 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=195 marginal_score=195 utility=195 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=6 task_index=0 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=7 task_index=2 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=8 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[2,7] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=9 task_index=9 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=10 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=11 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[10,11] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=12 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[9,12] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=13 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=75 marginal_score=75 utility=75 gained_goals=[0,15] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=14 task_index=1 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=15 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[6] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto rank=16 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=0 score_after=35 marginal_score=35 utility=35 gained_goals=[8] lost_goals=[] broken_constraints=[] preserved_constraints=[0,1,2,3,4,5,6,7,8]
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=420 action_cost=9 marginal_score=191 utility=191 gained_goals=[3,4,5,13,14] lost_goals=[] broken_constraints=[3,6] preserved_constraints=[0,1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=420 tail_reserve_ms=100 platform_remaining_ms=4989 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[4] lost_goals=[] broken_constraints=[0,3,6] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=3354 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[5] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2889 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[0] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=2417 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[1] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1953 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[2] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1486 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[9] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=true remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=1009 complete=true
[LOG]:[36m[3B][Candidate] phase=multi-goto-relocation task_index=16 behave=multi-goto-puton actions=4 duration_ms=440 action_cost=12 marginal_score=28 utility=28 gained_goals=[10] lost_goals=[] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[3B][Deadline] phase=multi-goto-relocation task_index=16 can_finish=false remaining_plan_ms=440 tail_reserve_ms=100 platform_remaining_ms=529 complete=true
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=1 task_index=10 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-32 marginal_score=-245 utility=-245 gained_goals=[10,11] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=2 task_index=11 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-32 marginal_score=-245 utility=-245 gained_goals=[10,11] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=3 task_index=6 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-72 marginal_score=-285 utility=-285 gained_goals=[6] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=4 task_index=7 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-72 marginal_score=-285 utility=-285 gained_goals=[7] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=5 task_index=8 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-72 marginal_score=-285 utility=-285 gained_goals=[8] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=6 task_index=12 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-72 marginal_score=-285 utility=-285 gained_goals=[12] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=7 task_index=14 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-72 marginal_score=-285 utility=-285 gained_goals=[14] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[36m[3B][Candidate] phase=greedy-round rank=8 task_index=15 behave=goto legacy_choice=false eligible=true complete=true actions=2 duration_ms=220 action_cost=5 score_before=213 score_after=-72 marginal_score=-285 utility=-285 gained_goals=[15] lost_goals=[0,1,2,3,4,5,9,13] broken_constraints=[] preserved_constraints=[1,2,4,5,7,8]
[LOG]:[Scheduler] filtered task=10 stable_id=10 marginal=-245 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=11 stable_id=11 marginal=-245 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=6 stable_id=6 marginal=-285 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=7 stable_id=7 marginal=-285 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=8 stable_id=8 marginal=-285 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=12 stable_id=12 marginal=-285 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=14 stable_id=14 marginal=-285 reason=nonpositive_single
[LOG]:[Scheduler] filtered task=15 stable_id=15 marginal=-285 reason=nonpositive_single
[LOG]:[Scheduler] greedy task=18446744073709551615 marginal=0 remaining_ms=528 group_attempt=true
[LOG]:[GuardedDecision] outcome=greedy reason=unverified_storage cumulative_ms=0
[LOG]:[Probe] {"schema":"probe.v2","event":"legacy_proposal","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"6","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=6,stable_id=6,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=6,stable_id=6,filter=nonpositive_single,fact=LOCATION:15,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=6,stable_id=6,filter=nonpositive_single,fact=INSIDE:15,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=7,stable_id=7,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=7,stable_id=7,filter=nonpositive_single,fact=LOCATION:17,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=7,stable_id=7,filter=nonpositive_single,fact=INSIDE:17,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=8,stable_id=8,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=8,stable_id=8,filter=nonpositive_single,fact=LOCATION:18,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=8,stable_id=8,filter=nonpositive_single,fact=INSIDE:18,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=10,stable_id=10,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=10,stable_id=10,filter=nonpositive_single,fact=LOCATION:10,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=10,stable_id=10,filter=nonpositive_single,fact=INSIDE:10,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=11,stable_id=11,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=11,stable_id=11,filter=nonpositive_single,fact=LOCATION:11,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=11,stable_id=11,filter=nonpositive_single,fact=INSIDE:11,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=12,stable_id=12,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=12,stable_id=12,filter=nonpositive_single,fact=LOCATION:12,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=12,stable_id=12,filter=nonpositive_single,fact=INSIDE:12,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=14,stable_id=14,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocked_task","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=15,stable_id=15,filter=nonpositive_single","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"blocking_fact","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"task=15,stable_id=15,filter=nonpositive_single,fact=LOCATION:22,reason=unverified","closed_reason":""}
[LOG]:[Probe] {"schema":"probe.v2","event":"candidate","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"constraint_safety_unknown","closed_reason":"","signature":"sense_at:7","kind":"MoveSense","target_location":7,"eligible":false,"information_estimate":0.332386,"expected_gain":-381.733,"probability_upper":1,"residual_mass":0.463068,"terminal_goal_loss":320,"answer_branches_evaluated":false,"answer_cache_hit":false,"answer_direct_value":0,"answer_after_value":0,"answer_net_value":0,"answer_branch_count":0,"continuation_cost":10,"constraint_risk_count":4,"cost":5,"duration_ms":220,"fact_count":4,"potential_goal_value":80,"stable_id":10,"constraint_result":"constraint_safety_unknown","facts":[{"field":"LOCATION","id":10,"task":10,"stable_task_id":10,"reason":"unverified","location_hints":[{"location":7,"source":"object_location:claim_source=1"}]},{"field":"INSIDE","id":10,"task":10,"stable_task_id":10,"reason":"unverified","location_hints":[{"location":7,"source":"object_location:claim_source=1"}]},{"field":"LOCATION","id":11,"task":11,"stable_task_id":11,"reason":"unverified","location_hints":[{"location":7,"source":"object_location:claim_source=1"}]},{"field":"INSIDE","id":11,"task":11,"stable_task_id":11,"reason":"unverified","location_hints":[{"location":7,"source":"object_location:claim_source=1"}]}],"answer_branches":[],"verification_routes":[]}
[LOG]:[Probe] {"schema":"probe.v2","event":"candidate","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"constraint_safety_unknown","closed_reason":"","signature":"sense_at:11","kind":"MoveSense","target_location":11,"eligible":false,"information_estimate":0.332386,"expected_gain":-393.366,"probability_upper":0.795455,"residual_mass":0.463068,"terminal_goal_loss":320,"answer_branches_evaluated":false,"answer_cache_hit":false,"answer_direct_value":0,"answer_after_value":0,"answer_net_value":0,"answer_branch_count":0,"continuation_cost":5,"constraint_risk_count":4,"cost":5,"duration_ms":220,"fact_count":2,"potential_goal_value":40,"stable_id":6,"constraint_result":"constraint_safety_unknown","facts":[{"field":"LOCATION","id":15,"task":6,"stable_task_id":6,"reason":"unverified","location_hints":[{"location":11,"source":"object_location:claim_source=1"}]},{"field":"INSIDE","id":15,"task":6,"stable_task_id":6,"reason":"unverified","location_hints":[{"location":11,"source":"object_location:claim_source=1"}]}],"answer_branches":[],"verification_routes":[]}
[LOG]:[Probe] {"schema":"probe.v2","event":"candidate","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"constraint_safety_unknown","closed_reason":"","signature":"sense_at:13","kind":"MoveSense","target_location":13,"eligible":false,"information_estimate":0.332386,"expected_gain":-393.366,"probability_upper":0.795455,"residual_mass":0.463068,"terminal_goal_loss":320,"answer_branches_evaluated":false,"answer_cache_hit":false,"answer_direct_value":0,"answer_after_value":0,"answer_net_value":0,"answer_branch_count":0,"continuation_cost":5,"constraint_risk_count":4,"cost":5,"duration_ms":220,"fact_count":2,"potential_goal_value":40,"stable_id":7,"constraint_result":"constraint_safety_unknown","facts":[{"field":"LOCATION","id":17,"task":7,"stable_task_id":7,"reason":"unverified","location_hints":[{"location":13,"source":"object_location:claim_source=1"}]},{"field":"INSIDE","id":17,"task":7,"stable_task_id":7,"reason":"unverified","location_hints":[{"location":13,"source":"object_location:claim_source=1"}]}],"answer_branches":[],"verification_routes":[]}
[LOG]:[Probe] {"schema":"probe.v2","event":"candidate","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"constraint_safety_unknown","closed_reason":"","signature":"sense_at:14","kind":"MoveSense","target_location":14,"eligible":false,"information_estimate":0.332386,"expected_gain":-393.366,"probability_upper":0.795455,"residual_mass":0.463068,"terminal_goal_loss":320,"answer_branches_evaluated":false,"answer_cache_hit":false,"answer_direct_value":0,"answer_after_value":0,"answer_net_value":0,"answer_branch_count":0,"continuation_cost":5,"constraint_risk_count":4,"cost":5,"duration_ms":220,"fact_count":2,"potential_goal_value":40,"stable_id":8,"constraint_result":"constraint_safety_unknown","facts":[{"field":"LOCATION","id":18,"task":8,"stable_task_id":8,"reason":"unverified","location_hints":[{"location":14,"source":"object_location:claim_source=1"}]},{"field":"INSIDE","id":18,"task":8,"stable_task_id":8,"reason":"unverified","location_hints":[{"location":14,"source":"object_location:claim_source=1"}]}],"answer_branches":[],"verification_routes":[]}
[LOG]:[Probe] {"schema":"probe.v2","event":"candidate","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"constraint_safety_unknown","closed_reason":"","signature":"sense_at:8","kind":"MoveSense","target_location":8,"eligible":false,"information_estimate":0.332386,"expected_gain":-393.366,"probability_upper":0.795455,"residual_mass":0.463068,"terminal_goal_loss":320,"answer_branches_evaluated":false,"answer_cache_hit":false,"answer_direct_value":0,"answer_after_value":0,"answer_net_value":0,"answer_branch_count":0,"continuation_cost":5,"constraint_risk_count":4,"cost":5,"duration_ms":220,"fact_count":2,"potential_goal_value":40,"stable_id":12,"constraint_result":"constraint_safety_unknown","facts":[{"field":"LOCATION","id":12,"task":12,"stable_task_id":12,"reason":"unverified","location_hints":[{"location":8,"source":"object_location:claim_source=1"}]},{"field":"INSIDE","id":12,"task":12,"stable_task_id":12,"reason":"unverified","location_hints":[{"location":8,"source":"object_location:claim_source=1"}]}],"answer_branches":[],"verification_routes":[]}
[LOG]:[Probe] {"schema":"probe.v2","event":"candidate","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"constraint_safety_unknown","closed_reason":"","signature":"sense_at:15","kind":"MoveSense","target_location":15,"eligible":false,"information_estimate":0.590909,"expected_gain":-384.318,"probability_upper":0.636364,"residual_mass":0.0454545,"terminal_goal_loss":320,"answer_branches_evaluated":false,"answer_cache_hit":false,"answer_direct_value":0,"answer_after_value":0,"answer_net_value":0,"answer_branch_count":0,"continuation_cost":5,"constraint_risk_count":4,"cost":5,"duration_ms":220,"fact_count":1,"potential_goal_value":40,"stable_id":15,"constraint_result":"constraint_safety_unknown","facts":[{"field":"LOCATION","id":22,"task":15,"stable_task_id":15,"reason":"unverified","location_hints":[{"location":15,"source":"object_location:claim_source=1"}]}],"answer_branches":[],"verification_routes":[]}
[LOG]:[Probe] {"schema":"probe.v2","event":"stop","world_revision":37,"total_probes":0,"probe_cost_spent":0,"max_same_ask":3,"authorized_constraint_risk_count":0,"consecutive_no_progress":0,"policy":[8,2,32],"reason":"constraint_rejected","closed_reason":""}
[LOG]:[Scheduler] stop reason=no_qualified_positive_single
[LOG]:[36m[3A][final] goals=8/16 (unknown=7), constraints=0/9 (unknown=4), base_score=213, action_cost=107, elapsed=4477ms, remaining=523ms
[LOG]:[36m[3A][final] completed_goals=[0:goto,1:goto,2:goto,3:goto,4:goto,5:goto,9:goto,13:goto], satisfied_constraints=[]
