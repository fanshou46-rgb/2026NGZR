# Aborted setup

Initial input audit compared Windows CRLF bytes directly with upstream LF hashes. No benchmark pairs ran. Later runs record actual byte hashes and validate LF-normalized upstream identity without changing input files.
