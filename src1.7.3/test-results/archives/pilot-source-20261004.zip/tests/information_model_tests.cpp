#include "rdfw.hpp"
#include <cassert>
#include <cmath>
#include <cstdlib>
using namespace _home;
namespace _home { struct InformationModelTestAccess {
    static CandidatePlan project(RDFW& w,unsigned id,LocationHypothesis h,std::size_t task) {return w.ProjectVerification(id,h,task);}
    static void evaluate(RDFW& w,ProbeCandidate& p) {w.EvaluateAskBranches(p);}
    static LocationBelief& belief(RDFW& w,unsigned id) {return w.BeliefFor(id);}
}; }
using A=InformationModelTestAccess;
static bool close(double a,double b) {return std::abs(a-b)<1e-9;}
int main(int argc,char** argv) {
    assert(argc==3);const int test=std::atoi(argv[2]);
    AskObservationModel model({{'a',1},{'a',2}},.6,.3,.1,0);
    LocationBelief belief;belief.initialize({{'a',1},{'a',2}},{'?',-1});
    if(test==0) {
        for(auto world:std::set<LocationHypothesis>{{'a',1},{'a',2},{'?',-1}}) {
            double sum=0;for(auto o:model.observations())sum+=model.likelihood(o,world);
            assert(close(sum,1));
        }
        assert(close(model.likelihood({'a',1},{'a',1}),.75));
        assert(close(model.likelihood({'a',1},{'a',2}),.15));return 0;
    }
    if(test==1) {
        double sum=0;for(auto o:model.observations())sum+=belief.observationProbability(o,model);assert(close(sum,1));
        auto next=belief.posterior({'a',1},model);
        assert(close(next.probability({'a',1}),5.0/7));
        assert(close(next.probability({'a',2}),1.0/7));
        assert(close(next.probability({'?',-1}),1.0/7));
        assert(belief.posterior({'?',-1},model).distribution()==belief.distribution());return 0;
    }
    if(test==2) {
        assert(belief.observe({'a',1},model,11));auto first=belief.distribution();
        assert(!belief.observe({'a',1},model,11) && belief.distribution()==first);
        assert(belief.observe({'a',1},model,12) && belief.probability({'a',1})>first.at({'a',1}));return 0;
    }
    VerificationRoute a;a.hypothesis={'a',1};a.success_value=40;a.failure_value=-5;a.worst_duration=std::chrono::milliseconds(400);a.feasible=true;
    auto b=a;b.hypothesis={'a',2};
    if(test==3) {
        auto value=InformationPlanner::ask(belief,model,{a,b},2,std::chrono::milliseconds(1000));
        double p=0;for(auto branch:value.branches)p+=branch.probability;assert(close(p,1));
        // Independently enumerate joint P(world,reply); one route per reply, no oracle.
        double total=0;
        for(auto branch:value.branches) for(auto world:belief.distribution())
            total+=world.second*model.likelihood(branch.observation,world.first)*
                (branch.selected_route.first=='?'?0:world.first==branch.selected_route?40:-5);
        assert(close(total,value.after_answer_value));assert(close(value.direct_value,10));
        assert(value.net_value>0 && value.after_answer_value<40);return 0;
    }
    if(test==4) {
        belief.confirm({'a',1});auto value=InformationPlanner::ask(belief,model,{a,b},2,std::chrono::milliseconds(1000));
        assert(close(value.net_value,-2));return 0; // known world: asking cannot improve the route
    }
    if(test==5) {
        auto value=InformationPlanner::ask(belief,model,{a,b},2,std::chrono::milliseconds(450),std::chrono::milliseconds(100));
        assert(close(value.after_answer_value,0) && close(value.net_value,-12));return 0;
    }
    if(test==6) {
        AskObservationModel no_information({{'a',1},{'a',2}},0,.9,.1,0);
        auto value=InformationPlanner::ask(belief,no_information,{a,b},2,std::chrono::milliseconds(1000));
        assert(close(value.net_value,-2));return 0;
    }
    auto owner=std::make_shared<RDFW>();auto& w=*owner;char name[]="info",option[]="-path";char* args[]={name,option,argv[1]};w.Init(3,args);w.stage=2;
    assert(w.ParseEnv("(hold 0) (plate 0) (at 0 1) (sort 1 human) (size 1 big) (at 1 1) "
        "(sort 2 cupboard) (size 2 big) (type 2 container) (at 2 2) (closed 2) "
        "(sort 3 book) (size 3 small) (at 3 2) (sort 4 table) (size 4 big) (at 4 4)"));
    assert(w.ParseInstruction("(:task (pickup X) (:cond (id X 3)))"));w.Cons_plan();
    if(test==7) {
        auto dist=A::belief(w,3).distribution();auto state=w.DebugStateSnapshot();
        auto plan=A::project(w,3,{'a',4},0);
        assert(plan.dry_run_succeeded && plan.marginal_score>0);
        assert(plan.actions.size()==3 && plan.actions[0].name=="Move" && plan.actions[1].name=="Sense" && plan.actions[2].name=="PickUp");
        assert(w.TestPlatformCalls()==0 && w.DebugStateSnapshot()==state && A::belief(w,3).distribution()==dist);
        assert(w.FactLocation(3)==UNKNOWN && w.FactInside(3)==UNKNOWN);return 0;
    }
    if(test==8) {
        w.ApplyStateValue(StateField::LOCATION,2,2,true,EvidenceSource::SENSE);
        w.ApplyStateValue(StateField::CONTAINER_STATE,2,0,true,EvidenceSource::SENSE);w.SetHold(nullptr);w.SetPlate(nullptr);
        auto state=w.DebugStateSnapshot();auto plan=A::project(w,3,{'i',2},0);
        assert(plan.dry_run_succeeded && plan.marginal_score>0);
        assert(plan.actions.size()==4 && plan.actions[1].name=="Open" && plan.actions[2].name=="Sense" && plan.actions[3].name=="TakeOut");
        assert(w.TestPlatformCalls()==0 && w.DebugStateSnapshot()==state && w.FactInside(3)==UNKNOWN);return 0;
    }
    if(test==9) {
        auto state=w.DebugStateSnapshot();auto plan=A::project(w,3,{'i',2},0);
        assert(!plan.dry_run_succeeded && w.DebugStateSnapshot()==state && w.TestPlatformCalls()==0);return 0;
    }
    if(test==10) {
        A::belief(w,3).answer({'a',4});w.ApplyStateValue(StateField::LOCATION,3,1,true,EvidenceSource::ACTION_SUCCESS);
        w.ApplyStateValue(StateField::INSIDE,3,0,true,EvidenceSource::ACTION_SUCCESS);
        assert(close(A::belief(w,3).probability({'a',1}),1));return 0;
    }
    assert(false);
}
