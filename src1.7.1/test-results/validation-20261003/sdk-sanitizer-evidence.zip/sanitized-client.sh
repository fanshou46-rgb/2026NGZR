#!/bin/bash
export LD_PRELOAD=/usr/lib/gcc/x86_64-linux-gnu/7/libasan.so:/tmp/rdfw171-tail-final-20261003/seed.so
export ASAN_OPTIONS=detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
exec /tmp/rdfw171-sdk-sanitizer-tail-final-20261003/example "$@"
