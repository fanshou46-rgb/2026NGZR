#include "joint_world.hpp"
#include "evaluate.h"
#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
using namespace _home;
static bool sdkAction(Evaluate& sdk,const JointAction& a) {
    switch(a.kind) {
    case JointActionKind::MOVE:return sdk.EvaluateMove(a.a);
    case JointActionKind::PICKUP:return sdk.EvaluatePickUp(a.a);
    case JointActionKind::PUTDOWN:return sdk.EvaluatePutDown(a.a);
    case JointActionKind::TOPLATE:return sdk.EvaluateToPlate(a.a);
    case JointActionKind::FROMPLATE:return sdk.EvaluateFromPlate(a.a);
    case JointActionKind::OPEN:return sdk.EvaluateOpen(a.a);
    case JointActionKind::CLOSE:return sdk.EvaluateClose(a.a);
    case JointActionKind::PUTIN:return sdk.EvaluatePutIn(a.a,a.b);
    case JointActionKind::TAKEOUT:return sdk.EvaluateTakeOut(a.a,a.b);
    default:assert(false);return false;
    }
}
static std::string domain(const JointWorld& w) {
    std::ostringstream s;s<<"(:domain (at 0 "<<w.robot<<") (hold "<<w.hand<<") (plate "<<w.plate<<") ";
    for(const auto& item:w.objects) {
        const auto& o=item.second;auto id=item.first;
        s<<"(sort "<<id<<' '<<(o.container?"cupboard":o.small?"cup":"table")<<") (size "<<id<<' '<<(o.small?"small":"big")<<") ";
        if(o.at>=0)s<<"(at "<<id<<' '<<o.at<<") ";
        if(o.inside)s<<"(inside "<<id<<' '<<o.inside<<") ";
        if(o.container)s<<"(type "<<id<<" container) ("<<(o.opened?"opened":"closed")<<' '<<id<<") ";
    }
    return s.str()+")";
}
int main(int argc,char** argv) {
    assert(argc==2);int test=std::atoi(argv[1]);
    JointWorld w;w.robot=1;w.locations={1,2};
    w.objects={{1,{false,false,1}},{2,{false,true,1,0,false}},
               {3,{true,false,-1,2}},{4,{true,false,2}},{5,{false,false,2}}};
    using K=JointActionKind;
    std::vector<JointAction> actions;
    if(test==0)actions={{K::SENSE},{K::OPEN,2},{K::SENSE},{K::TAKEOUT,3,2},{K::MOVE,2},{K::SENSE},{K::TOPLATE,3},{K::SENSE},{K::FROMPLATE,3},{K::PUTDOWN,3}};
    else if(test==1) {w.hand=3;w.objects[3].inside=0;w.plate=4;actions={{K::SENSE},{K::MOVE,2},{K::SENSE},{K::TOPLATE,3},{K::FROMPLATE,4},{K::OPEN,2}};}
    else if(test==2) {w.objects[3].at=1;actions={{K::SENSE},{K::PICKUP,3},{K::SENSE},{K::PUTDOWN,3},{K::SENSE}};}
    else if(test==3)actions={{K::TAKEOUT,3,2},{K::OPEN,2},{K::TAKEOUT,3,2},{K::CLOSE,2},{K::PUTDOWN,3},{K::CLOSE,2},{K::CLOSE,2}};
    else if(test==4)actions={{K::MOVE,1},{K::CLOSE,2},{K::OPEN,2},{K::OPEN,2},{K::MOVE,2},{K::OPEN,2},{K::SENSE}};
    else if(test==5) {w.hand=3;w.objects[3].inside=0;w.objects[3].at=1;w.objects[2].opened=true;actions={{K::PUTIN,3,2},{K::SENSE},{K::CLOSE,2},{K::SENSE},{K::OPEN,2},{K::SENSE},{K::TAKEOUT,3,2}};}
    else assert(false);
    Evaluate sdk;std::string name="joint-"+std::to_string(test);sdk.newteam(name);
    std::string env=domain(w),task="(:ins (:task (goto X) (:cond (sort X table) (id X 5))))";
    assert(sdk.init_et(env.c_str(),env.size()));assert(sdk.init_it(task.c_str(),task.size()));
    int cost=0;
    for(std::size_t n=0;n<actions.size();++n) {
        const auto& a=actions[n];auto next=JointDynamics::step(w,a);cost+=a.cost();
        if(a.kind==K::SENSE) {
            std::vector<unsigned> ids;sdk.EvaluateSense(ids);
            std::set<unsigned> actual(ids.begin(),ids.end());
            if(actual!=next.observation.ids) {std::cerr<<name<<" step "<<n<<" sense mismatch\n";return 1;}
        } else {
            bool actual=sdkAction(sdk,a);
            if(actual!=next.observation.success) {std::cerr<<name<<" step "<<n<<" feedback mismatch\n";return 1;}
        }
        w=std::move(next.world);
    }
    int expected=(w.atLocation(5,w.robot)?40:0)-cost;
    int actual=sdk.EndEvaluation(5.0);
    std::cerr<<name<<" expected="<<expected<<" SDK="<<actual<<'\n';assert(expected==actual);
    for(const char* file:{"vstate.lp","vanswer.txt","vaction.lp"}) {
        std::ifstream input(file);std::ofstream output(name+"."+file);output<<input.rdbuf();
    }
}
