from pathlib import Path
import json, hashlib, re
root=Path(__file__).resolve().parents[3]
source=root/'src1.10'
expected=json.loads((source/'test-results/development-20261004/noise-pilot-seed20260924/build-current/build.json').read_text())['sources']
target=source/'test-results/development-20261004/noise-pilot-source'
target.mkdir(exist_ok=True)
old={'canonical_state.cpp','state_mutation.cpp','terminal_checker.cpp',
     'tests/canonical_state_tests.cpp','tests/mutation_failure_tests.cpp','tests/state_invariant_tests.cpp'}
for name,digest in expected.items():
    data=(root/'src1.9'/name if name in old else source/name).read_bytes()
    if name=='rdfw.hpp':
        old_header=(root/'src1.9'/name).read_bytes()
        start=b'    struct StateProvenance {';end=b'    // \xe8\xbf\x99\xe9\x87\x8c'
        a=data.index(start);b=data.index(end,a)
        x=old_header.index(start);y=old_header.index(end,x)
        data=data[:a]+old_header[x:y]+data[b:]
    if name=='rdfw.cpp':
        original=(root/'src1.9'/name).read_bytes()
        # Only these two methods changed in the noise pilot. Copy whole methods
        # to preserve the original mixture of LF and CRLF byte for byte.
        for start,end in [(b'std::string RDFW::AskLoc(',b'void RDFW::Sense()'),
                          (b'bool RDFW::ParseEnv(',None)]:
            a=data.index(start);b=data.index(end,a) if end else len(data)
            x=original.index(start);y=original.index(end,x) if end else len(original)
            original=original[:x]+data[a:b]+original[y:]
        data=original
    if name=='tests/CMakeLists.txt':
        text=data.decode().replace('foreach(case RANGE 0 44)','foreach(case RANGE 0 32)')
        text=re.sub(r'    add_executable\(official_storage_authority_tests.*?    endforeach\(\)\n','',text,flags=re.S)
        text=text.replace('foreach(case RANGE 0 32)\n','foreach(case RANGE 0 32)\r\n')
        data=text.encode()
    assert hashlib.sha256(data).hexdigest()==digest,(name,hashlib.sha256(data).hexdigest(),digest)
    path=target/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
(target/'RECONSTRUCTION.json').write_text(json.dumps({'method':'reconstruct pre-authority edits, verify every byte against independently recorded pilot SHA-256','sources':expected},indent=2))
print('Exact verified pilot source snapshot:',len(expected),'files')
