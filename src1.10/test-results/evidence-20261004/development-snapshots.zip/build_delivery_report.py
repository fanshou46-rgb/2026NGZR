from pathlib import Path
import json,csv,shutil,sys
sys.stdout.reconfigure(encoding='utf8')
source=Path(__file__).resolve().parents[2]
root=source/'test-results/validation-20261004'
allrows=[];summaries=[]
for seed in (20260924,20260925):
    src=root/('final-seed'+str(seed));dst=root/('review-seed'+str(seed));dst.mkdir(exist_ok=True)
    for p in src.glob('*.json'):shutil.copy2(p,dst/p.name)
    s=json.loads((src/'summary.json').read_text())['all'];summaries.append((seed,s))
    rows=json.loads((src/'results.json').read_text())
    for r in rows:r['seed']=seed
    allrows.extend(rows)
totals={a:{k:sum(s[a][k] for _,s in summaries) for k in summaries[0][1][a]} for a in ('baseline','current')}
for a in totals:
    totals[a]['platform_seconds']=round(sum(r[a]['platform_seconds'] for r in allrows),3)
    totals[a]['client_crashes']=sum(r[a].get('client_exit') not in (0,None) for r in allrows)
    totals[a]['external_timeouts']=sum(bool(r[a].get('external_timeout')) for r in allrows)
counts={
 'base_improved':sum(r['current']['base']>r['baseline']['base'] for r in allrows),
 'base_worsened':sum(r['current']['base']<r['baseline']['base'] for r in allrows),
 'goals_worsened':sum(r['current']['final_goals']<r['baseline']['final_goals'] for r in allrows),
 'same_actions':sum(r['current']['action_sequence']==r['baseline']['action_sequence'] for r in allrows),
 'stage1_pairs':sum(r['stage']==1 for r in allrows)}
save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
save(root/'combined-summary.json',dict(pairs=len(allrows),totals=totals,counts=counts))
save(root/'combined-results.json',allrows)
tab=[]
for r in allrows:
    b,c=r['baseline'],r['current'];row=dict(seed=r['seed'],id=r['id'],mode=r['mode'],stage=r['stage'])
    for k in ('final_goals','credited_constraints','action_cost','base','official_score','platform_seconds'):
        row[k+'_delta']=round(c[k]-b[k],3)
    row['sdk_timeout_delta']=int(c['platform_timed_out'])-int(b['platform_timed_out'])
    row['client_crash_delta']=int(c.get('client_exit') not in (0,None))-int(b.get('client_exit') not in (0,None))
    row['same_actions']=b['action_sequence']==c['action_sequence']
    tab.append(row)
negative=lambda r:any(r[k+'_delta']<0 for k in ('final_goals','credited_constraints','base','official_score')) or r['action_cost_delta']>0 or r['sdk_timeout_delta']>0 or r['client_crash_delta']>0
for name,rows in [('PAIR_RESULTS.csv',tab),('REGRESSIONS.csv',[r for r in tab if negative(r)])]:
    with (root/name).open('w',encoding='utf-8-sig',newline='') as f:
        out=csv.DictWriter(f,fieldnames=list(tab[0]));out.writeheader();out.writerows(rows)
lines=['| 种子 | 基础分（旧→新） | 官方分（旧→新） | G（旧→新） | SDK 超时（旧→新） |',
       '|---|---:|---:|---:|---:|']
for seed,s in summaries:
    b,c=s['baseline'],s['current'];lines.append(f"| {seed} | {b['base']}→{c['base']} | {b['official_score']}→{c['official_score']} | {b['final_goals']}→{c['final_goals']} | {b['timeouts']}→{c['timeouts']} |")
b,c=totals['baseline'],totals['current']
lines.extend(['',f"最终 56 对：基础分 {b['base']}→{c['base']}（{c['base']-b['base']:+d}），官方分 {b['official_score']}→{c['official_score']}（{c['official_score']-b['official_score']:+d}）；G {b['final_goals']}→{c['final_goals']}，C {b['credited_constraints']}→{c['credited_constraints']}，K {b['action_cost']}→{c['action_cost']}。",
f"平台耗时合计 {b['platform_seconds']}→{c['platform_seconds']} 秒，SDK 超时 {b['timeouts']}→{c['timeouts']}；客户端崩溃 {b['client_crashes']}→{c['client_crashes']}，外部超时 {b['external_timeouts']}→{c['external_timeouts']}，缺失评分 {b['unscored']}→{c['unscored']}。",
f"基础分 {counts['base_improved']} 对提高、{counts['base_worsened']} 对下降；{counts['goals_worsened']} 对目标下降；{counts['same_actions']} 对动作序列相同。全部 56 对列在 PAIR_RESULTS.csv，任一非时间指标不利的 {sum(negative(r) for r in tab)} 对列在 REGRESSIONS.csv。4 对 Stage 1 动作与基础分相同；Stage 1 其它题未完整验证。",
'',"完整记录含两组先导共 76 对、152 次生产 SDK 运行；先导与最终结果分别保留，未用有利重跑替换不利记录。所有最终源、输入、SDK 和执行边界审计通过。最终二进制 SHA-256：旧版 `5060ab0353a748fe077f4a07a77390aaf3d91f2bde0ccb918c7b749798f24659`，新版 `e4328c6bf6fe8958efd613a5b1d908912fe956ea91c18cad3623e609ecacb8d6`。",
'',"结论：本轮修正了已证实的噪声与事实判断错误，但历史题总体性能退化，不建议替换比赛版本。保留为联合模型开发检查点，后续应补真实评分/先验桥接与路径价值，不能把内核通过说成目标完成。"])
report=root/'REPORT.md';data=report.read_text(encoding='utf8')
data=data.replace('详细结果将在两轮完成后加入；最终目录与证据归档保留每一对结果，先导记录单独统计。','\n'.join(lines))
report.write_bytes(data.encode('utf8'))
print(json.dumps(dict(pairs=len(allrows),totals=totals,counts=counts),ensure_ascii=False))
