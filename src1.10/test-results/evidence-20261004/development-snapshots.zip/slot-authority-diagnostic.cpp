#include "rdfw.hpp"
#include "joint_world.hpp"
#include <cassert>
#include <iostream>
namespace _home { struct InformationModelTestAccess {
 static void sense(RDFW& w){w.SenseCurrentLocationOnly(true);}
 static bool notStored(RDFW& w,unsigned id){return w.IsNotStoredFact(id);}
}; }
using namespace _home;
int main(int argc,char** argv){
 assert(argc==2);auto owner=std::make_shared<RDFW>();auto& w=*owner;
 char name[]="slot-proof",path[]="-path";char* args[]={name,path,argv[1]};w.Init(3,args);w.stage=2;
 assert(w.ParseEnv("(hold 0) (plate 0) (at 0 1) (sort 1 table) (size 1 big) (at 1 1) (sort 3 cup) (size 3 small) (at 3 1)"));
 JointWorld floor;floor.robot=1;floor.locations={1};floor.objects={{1,{false,false,1}},{3,{true,false,1}}};
 auto held=floor;held.hand=3;assert(floor.visible()==held.visible());
 w.SetSenseResult({1,3});InformationModelTestAccess::sense(w);
 bool claim=InformationModelTestAccess::notStored(w,3);
 std::cout<<"same SDK-model observation for floor and held; canonical hand="<<w.FactValue(StateField::HOLD)
 <<" plate="<<w.FactValue(StateField::PLATE)<<" not-stored="<<claim<<"\n";
 // An indistinguishable held world refutes this stronger authority claim.
 return claim?1:0;
}
